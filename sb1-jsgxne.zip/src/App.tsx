import React from 'react';
import { Bitcoin } from 'lucide-react';
import { Calculator } from './components/Calculator';
import { FAQ } from './components/FAQ';

export function App() {
  return (
    <div className="min-h-screen bg-[#242b40] text-white">
      <header className="border-b border-white/10 backdrop-blur-lg bg-[#242b40]/80 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-2">
            <Bitcoin className="w-8 h-8 text-[#FF8B3C]" />
            <span className="font-bold text-xl">Crypto Profit Calculator</span>
          </div>
        </div>
      </header>

      <main>
        <section className="max-w-4xl mx-auto px-4 py-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-center bg-gradient-to-r from-white to-[#FF8B3C] bg-clip-text text-transparent">
            Crypto Profit Calculator Pro
          </h1>
          <p className="text-lg text-center mb-12 text-gray-300">
            The most accurate crypto profit calculator for serious investors
          </p>
          
          <Calculator />
          <FAQ />
        </section>
      </main>
    </div>
  );
}