import React, { useState, useEffect } from 'react';
import { DollarSign, Percent } from 'lucide-react';
import { NumberInput } from './NumberInput';
import { ResultCard } from './ResultCard';

interface CalculationResult {
  profit: number;
  percentage: number;
}

export function Calculator() {
  const [investment, setInvestment] = useState<number>(1000);
  const [buyPrice, setBuyPrice] = useState<number>(50000);
  const [sellPrice, setSellPrice] = useState<number>(55000);
  const [investmentFee, setInvestmentFee] = useState<number>(0.1);
  const [exitFee, setExitFee] = useState<number>(0.1);
  const [result, setResult] = useState<CalculationResult>({ profit: 0, percentage: 0 });

  useEffect(() => {
    calculateProfit();
  }, [investment, buyPrice, sellPrice, investmentFee, exitFee]);

  const calculateProfit = () => {
    const quantity = investment / buyPrice;
    const investmentFeeAmount = (investment * investmentFee) / 100;
    const sellAmount = quantity * sellPrice;
    const exitFeeAmount = (sellAmount * exitFee) / 100;
    const totalFees = investmentFeeAmount + exitFeeAmount;
    
    const profit = sellAmount - investment - totalFees;
    const percentage = (profit / investment) * 100;

    setResult({ profit, percentage });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="space-y-6">
        <NumberInput
          label="Investment Amount"
          value={investment}
          onChange={setInvestment}
          icon={<DollarSign className="w-5 h-5 text-gray-400" />}
          tooltip="Enter your initial investment amount in USD"
        />

        <NumberInput
          label="Buy Price"
          value={buyPrice}
          onChange={setBuyPrice}
          icon={<DollarSign className="w-5 h-5 text-gray-400" />}
          tooltip="Enter the price at which you bought or plan to buy"
        />

        <NumberInput
          label="Sell Price"
          value={sellPrice}
          onChange={setSellPrice}
          icon={<DollarSign className="w-5 h-5 text-gray-400" />}
          tooltip="Enter your target selling price"
        />

        <NumberInput
          label="Investment Fee (%)"
          value={investmentFee}
          onChange={setInvestmentFee}
          icon={<Percent className="w-5 h-5 text-gray-400" />}
          tooltip="Enter the fee percentage charged when buying"
        />

        <NumberInput
          label="Exit Fee (%)"
          value={exitFee}
          onChange={setExitFee}
          icon={<Percent className="w-5 h-5 text-gray-400" />}
          tooltip="Enter the fee percentage charged when selling"
        />
      </div>

      <ResultCard result={result} investment={investment} />
    </div>
  );
}