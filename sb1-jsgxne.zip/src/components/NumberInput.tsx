import React from 'react';
import { Tooltip } from './Tooltip';
import { HelpCircle } from 'lucide-react';

interface NumberInputProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  icon: React.ReactNode;
  tooltip: string;
}

export function NumberInput({ label, value, onChange, icon, tooltip }: NumberInputProps) {
  return (
    <div className="relative">
      <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
        {label}
        <Tooltip content={tooltip}>
          <HelpCircle className="w-4 h-4 text-gray-400" />
        </Tooltip>
      </label>
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          {icon}
        </div>
        <input
          type="number"
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="block w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-lg focus:ring-2 focus:ring-[#FF8B3C] focus:border-transparent transition-all text-white"
        />
      </div>
    </div>
  );
}