import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip as ChartTooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';

ChartJS.register(ArcElement, ChartTooltip, Legend);

interface ProfitChartProps {
  investment: number;
  profit: number;
}

export function ProfitChart({ investment, profit }: ProfitChartProps) {
  const data = {
    labels: ['Initial Investment', profit >= 0 ? 'Profit' : 'Loss'],
    datasets: [
      {
        data: [investment, Math.abs(profit)],
        backgroundColor: [
          'rgba(255, 139, 60, 0.8)',
          profit >= 0 ? 'rgba(34, 197, 94, 0.8)' : 'rgba(239, 68, 68, 0.8)',
        ],
        borderColor: [
          'rgba(255, 139, 60, 1)',
          profit >= 0 ? 'rgba(34, 197, 94, 1)' : 'rgba(239, 68, 68, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          color: 'rgba(255, 255, 255, 0.8)',
          font: {
            size: 14,
          },
        },
      },
    },
  };

  return (
    <div className="h-64 mb-6">
      <Pie data={data} options={options} />
    </div>
  );
}