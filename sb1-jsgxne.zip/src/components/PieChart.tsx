import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface PieChartProps {
  investment: number;
  profit: number;
}

export function PieChart({ investment, profit }: PieChartProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    // Clear previous chart
    d3.select(svgRef.current).selectAll('*').remove();

    const width = 200;
    const height = 200;
    const radius = Math.min(width, height) / 2;

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height)
      .append('g')
      .attr('transform', `translate(${width / 2},${height / 2})`);

    const data = [
      { label: 'Investment', value: investment },
      { label: 'Profit/Loss', value: Math.abs(profit) }
    ];

    const color = d3.scaleOrdinal()
      .domain(['Investment', 'Profit/Loss'])
      .range(['#FF8B3C', profit >= 0 ? '#4ADE80' : '#F87171']);

    const pie = d3.pie<any>()
      .value(d => d.value)
      .sort(null);

    const arc = d3.arc()
      .innerRadius(radius * 0.6)
      .outerRadius(radius);

    const arcs = svg.selectAll('arc')
      .data(pie(data))
      .enter()
      .append('g');

    arcs.append('path')
      .attr('d', arc as any)
      .attr('fill', (d: any) => color(d.data.label) as string)
      .attr('stroke', '#242b40')
      .style('stroke-width', '2px')
      .style('opacity', 0.9);

    // Add 3D effect with gradients
    const defs = svg.append('defs');

    const gradient = defs.append('linearGradient')
      .attr('id', 'gradient')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '100%')
      .attr('y2', '100%');

    gradient.append('stop')
      .attr('offset', '0%')
      .attr('stop-color', 'white')
      .attr('stop-opacity', 0.3);

    gradient.append('stop')
      .attr('offset', '100%')
      .attr('stop-color', 'black')
      .attr('stop-opacity', 0.3);

    arcs.append('path')
      .attr('d', arc as any)
      .style('fill', 'url(#gradient)')
      .style('mix-blend-mode', 'overlay');

  }, [investment, profit]);

  return (
    <div className="flex justify-center items-center bg-white/10 rounded-lg p-4">
      <svg ref={svgRef}></svg>
    </div>
  );
}