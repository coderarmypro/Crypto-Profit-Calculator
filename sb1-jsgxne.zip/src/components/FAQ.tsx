import React from 'react';

export function FAQ() {
  const faqs = [
    {
      question: "Why use our Crypto Profit Calculator?",
      answer: "Our crypto profit calculator provides precise calculations based on your inputs, including investment amount, buy/sell prices, and fees. It's designed for both beginners and experienced traders to make informed decisions."
    },
    {
      question: "How does the Crypto Profit Calculator handle fees?",
      answer: "Our crypto profit calculator factors in both investment fees (when buying) and exit fees (when selling). These typically range from 0.1% to 1% depending on your chosen exchange."
    },
    {
      question: "Can this Crypto Profit Calculator handle multiple cryptocurrencies?",
      answer: "Yes, our crypto profit calculator works with any cryptocurrency as it's based on purchase price and sale price. Simply enter the correct prices for your chosen cryptocurrency."
    },
    {
      question: "Does the Crypto Profit Calculator include network fees?",
      answer: "Yes, you can include network fees (such as gas fees for ETH or transaction fees for BTC) in the fee percentages for more accurate profit calculations."
    },
    {
      question: "How does the Crypto Profit Calculator visualize results?",
      answer: "Our crypto profit calculator includes an interactive pie chart that shows your initial investment (orange) and potential profit/loss (green/red), making it easy to understand your position."
    },
    {
      question: "What's the difference between amount and percentage in the Crypto Profit Calculator?",
      answer: "The calculator shows both dollar amount and percentage returns. For example, a $100 profit on a $1000 investment would show as both $100 and 10% return."
    },
    {
      question: "How accurate is the Crypto Profit Calculator with fees?",
      answer: "Our calculator precisely accounts for both entry and exit fees. For example, a $1000 investment with 0.5% fees would factor in $5 for buying and the corresponding percentage for selling."
    },
    {
      question: "Why should I use a Crypto Profit Calculator before trading?",
      answer: "Using our crypto profit calculator helps you understand potential returns and the impact of fees before making trades, leading to better-informed investment decisions."
    },
    {
      question: "Can the Crypto Profit Calculator show potential losses?",
      answer: "Yes, if your sell price is lower than your buy price, our calculator will accurately display your potential losses in both dollar amount and percentage."
    },
    {
      question: "How can I maximize profits using the Crypto Profit Calculator?",
      answer: "Use our calculator to experiment with different scenarios, compare exchange fees, and understand how holding periods affect your potential returns after fees."
    }
  ];

  return (
    <section className="mt-16">
      <h2 className="text-2xl font-bold mb-8 text-[#FF8B3C]">
        Crypto Profit Calculator FAQ
      </h2>
      
      <div className="space-y-6">
        {faqs.map((faq, index) => (
          <div key={index} className="bg-white/5 rounded-lg p-6 hover:bg-white/10 transition-colors duration-200">
            <h3 className="text-lg font-medium mb-2">{faq.question}</h3>
            <p className="text-gray-300">{faq.answer}</p>
          </div>
        ))}
      </div>
    </section>
  );
}