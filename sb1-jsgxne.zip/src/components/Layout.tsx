import React from 'react';
import { Bitcoin } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div>
      <header className="border-b border-white/10 backdrop-blur-lg bg-[#242b40]/80 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-2">
            <Bitcoin className="w-8 h-8 text-[#FF8B3C]" />
            <span className="font-bold text-xl">Crypto Profit Calculator</span>
          </div>
        </div>
      </header>
      <main>{children}</main>
    </div>
  );
}