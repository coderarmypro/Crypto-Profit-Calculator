import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { ProfitChart } from './ProfitChart';

interface ResultCardProps {
  result: {
    profit: number;
    percentage: number;
  };
  investment: number;
}

export function ResultCard({ result, investment }: ResultCardProps) {
  const isProfit = result.profit >= 0;
  const Icon = isProfit ? TrendingUp : TrendingDown;
  const colorClass = isProfit ? 'text-green-400' : 'text-red-400';

  return (
    <div className="bg-white/5 rounded-xl p-6 border border-white/10">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-300">Result</h3>
        <Icon className={`w-6 h-6 ${colorClass}`} />
      </div>

      <ProfitChart investment={investment} profit={result.profit} />
      
      <div className="space-y-4">
        <div>
          <p className="text-sm text-gray-400">Profit/Loss</p>
          <p className={`text-2xl font-bold ${colorClass}`}>
            ${result.profit.toLocaleString()}
          </p>
        </div>
        
        <div>
          <p className="text-sm text-gray-400">Return</p>
          <p className={`text-2xl font-bold ${colorClass}`}>
            {result.percentage.toFixed(2)}%
          </p>
        </div>
      </div>
    </div>
  );
}